<template>
  <div class="bg-[#252627] bg-[url(/bg-img/WebBG.png)]">
   <Header />
    <ImgBar />
    <Games />
    <TrendGames />
    <NewProducts /> 
    <TrendGift />
    <TrendPayment/>
    <Text />  
  </div>
  <div class="bg-[url(/bg-img/WebBG.png)]">
    <Footer />
  </div>
</template>
