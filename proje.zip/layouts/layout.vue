<template>
    <Header />
    
    <TrendGames />
    <slot />

 
    <Footer />
</template>

<script setup></script>
