<template>
  <NuxtLayout>
    <NuxtPage />
    <ScrollToTop />
  </NuxtLayout>
</template>
