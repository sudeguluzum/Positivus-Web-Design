<template>
  <div class="relative w-full">
    <input
      type="text"
      placeholder="Epinpay'de ara..."
      class="w-full h-9 pl-4 pr-12 bg-white rounded-full shadow text-sm text-gray-700 placeholder-gray-400 focus:outline-none"
    />

    <button
      class="absolute -right-0.5 -top-1.5 transform w-12 h-12 flex items-center justify-center rounded-full bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] text-white"
    >
      <Icon name="material-symbols:search" class="text-xl" />
    </button>
  </div>
</template>
<script setup>


</script>
