

<template>
  <ul class="flex flex-col md:flex-row items-center gap-3">
    <li
      v-for="(item, index) in navItems"
      :key="index"
      :class="item.wrapperClass"
    >
      <NuxtLink
        :to="item.to"
        class="text-white flex items-center"
        @click="item.isSpecial ? (show = !show) : null"
      >
        <Icon v-if="item.icon" :name="item.icon" :class="item.iconClass" />
        <span>{{ item.label }}</span>
        <Icon
          v-if="item.extraIcon"
          :name="item.extraIcon"
          :class="item.extraIconClass"
        />
      </NuxtLink>
    </li>
  </ul>
</template>
<script setup>
const navItems = [
  {
    label: 'Favorilerim',
    icon: 'mdi:heart-outline',
    to: '/',
    iconClass: 'w-5 h-5 text-green-700 mr-1',
    textClass: 'text-white',
  },
  {
    label: 'Türkçe',
    icon: 'openmoji:flag-turkey',
    extraIcon: 'mingcute:down-line',
    iconClass: 'text-2xl mr-1',
    extraIconClass: 'w-5 h-5 text-white ml-1',
    to: '/',
    textClass: 'text-white',
  },
  {
    label: 'acililahmacun',
    to: '/',
    wrapperClass:
      'relative h-7 px-3 flex items-center text-white rounded-full bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E]',
    isSpecial: true,
  },
]
</script>