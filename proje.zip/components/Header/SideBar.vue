<template>
        <div>
          <HeaderAccountBarMenu class=""/>
          <HeaderDropDownMenuComp class=""/>
        </div>
</template>

<script setup>
// defineProps(["id", "name","icon"]);

</script>