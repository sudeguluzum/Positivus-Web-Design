<template>
  <div class="w-full bg-[#070B14] h-26 flex-center fixed z-50 top-0">
    <div
      class="max-w-[1060px] w-full px-4 flex items-center justify-between gap-1 mx-auto"
    >
      <HeaderLogo />
      <HeaderSearchbar class="hidden md:block w-full max-w-md"/>
     
      <HeaderAccountBar />
    </div>
  </div>
</template>
<script setup>

</script>