<template>
  <div class="relative w-full">
    <input
      type="text"
      placeholder="Enter your mail here..."
      class="w-full h-12 px-4 mb-4 bg-white border-2 border-gray-400/50 rounded-full text-sm text-gray-700 placeholder-gray-400"
    />

    <button
      class="absolute right-2 top-1.5 transform w-9 h-9 flex-center rounded-full bg-gradient-to-r from-[#1b9a88] to-[#1C3E7E] text-white"
    >
      <Icon name="mingcute:right-line" class="text-sm" />
    </button>
  </div>
</template>
