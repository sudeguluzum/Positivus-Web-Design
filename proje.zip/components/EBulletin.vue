<template>
  <div class=" py-8 px-4">
    <div class="max-w-6xl mx-auto">

      <div class="flex items-center  gap-2 mb-4">
        <NuxtImg src="chat_icon.png" class="w-15 h-15" />
        <h2 class="text-[#154983] text-2xl font-bold">E-Bültene Kaydolun</h2>
      </div>

      <div>
        <Email />
      </div>

      <p class="text-gray-400 text-sm">
        Mail bültenimize katılarak sen de bizden gelecek olan duyuru, <br> teklif ve fırsatlardan haberdar olabilirsin!
      </p>

    </div>
  </div>
</template>
<script setup>

</script>
