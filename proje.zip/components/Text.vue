<template>
  <div class="h-auto mx-auto max-w-5xl mt-15 pb-20">
    <div
      class="h-17 rounded-t-4xl bg-gradient-to-r from-[#1b9a88]/70 to-[#1C3E7E]/70 text-2xl backdrop-blur-sm text-white font-bold text-center flex-center"
    >
      <h2 class="text-2xl xs:text-3xl sm:text-4xl md:text-4xl">
        Türkiye'nin En Büyük Oyuncu Pazarı
      </h2>
    </div>
    <div class="bg-white px-10 py-2 leading-none text-sm rounded-b-4xl">
      <p>
        Dünyada ve Türkiye’de oyun severler tarafından sıklıkla tercih edilen
        oyunların sayısı gün geçtikçe artmaktadır. Kullanıcılar arası rekabetin
        de hızla artığı bu dönemde oyun karakterlerinizi ve hesabınızı
        geliştirmek isteyebilirsiniz. Bilgisayar veya mobil oyunları
        oynayacağınız sırada ek özelliklerle beraber karakterlerinizi yetenek,
        kostüm, kask, silah gibi ek özelliklerle farklı bir boyuta taşımanız
        mümkündür. Oyunlarda genellikle bu tarz ek özelliklere item veya skin
        denir. Bunların yanı sıra oynadığınız oyundan alacağınız keyfi maksimuma
        çıkarmak için epin alma yoluna gidebilir, oyunlarınızdaki bazı hamleleri
        kolaylıkla gerçekleştirirsiniz. Bu tarz özellikleri oyunlardan satın
        alabileceğiniz gibi daha uygun fiyatlara satın alabilme adına farklı
        platformları da deneyebilirsiniz. Item satış sitelerinden bu tarz
        özellikleri daha uygun fiyatlara alabilmeniz mümkündür. Epinpay olarak
        sizlere yaptığımız kampanyalarımızla beraber istediğiniz item’ları daha
        uygun fiyatlardan alırsınız. Sizlere sunduğumuz Item sat hizmetimiz ile,
        oyun içerisindeki mağazalardan çok daha uygun fiyatlara sitemizden
        alma-satma imkanı sağlarız.
        <span class="block h-4"></span>
        Skin, item, oyun parası alacağınız sırada satın alma işlemlerinizi
        yerine getireceğiniz platformlar da çok ciddi bir önem arz eder. Bazı
        platformlarda siparişi verilen skin’lerin hesaplara aktarılmadığı veya
        aktarıldıktan sonra hesaplarda sorun çıkarıldığı görülebilmektedir. Bu
        yüzden item satışı yapılacak olan siteler arasından birisini tercih
        edeceğiniz sırada mutlaka en güvenilir olan platformları tercih etmeniz
        gerekir.

        <span class="block h-4"></span>
        Gold bar, Yang/Won, Cabal Alz gibi oyun içerisinden satın almanızın
        mümkün olmadığı oyun paralarını da sitemiz aracılığı ile güvenle
        alabilir ve anında kullanmaya başlayabilirsiniz. Sitemizden item, skin
        ve oyun parası alma yoluna giden kişiler hesaplarında hiçbir problemle
        karşılaşmadan siparişlerini verebilmektedir. Sitemizde item ve skin
        sunmuş olduğumuz bazı oyunlar şu şekildedir:
      </p>
      <div>
        <NuxtLink
          to="/"
          class="text-black font-bold flex items-center justify-end px-2 py-1"
        >
          Devamını Oku
          <Icon name="mingcute:down-line" class="w-5 h-5 text-black" />
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<script setup></script>
