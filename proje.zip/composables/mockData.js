export default function () {
  return {
    menuList: ["Sude"],
    products: [{ name: "Pubg 1195 UC" }, { name: "Pubg 60 UC" }],
  };
}
