<template>
    <div class="flex-wrap pt-3">
        <NuxtImg src="Logo.png" class="h-14 min-w-44" />
        <h1 class="text-white text-center">Sude Gül ÜZÜM</h1>
      </div>
</template>