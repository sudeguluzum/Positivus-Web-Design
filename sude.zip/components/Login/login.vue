<template>
  <div class="h-screen w-screen bg-red-500"></div>
</template>

<script setup></script>
