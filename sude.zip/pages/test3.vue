<template>
  <div class="max-md:hidden bg-red-500">selam</div>
  <div class="hidden max-md:block bg-green-500">
    <div>Sude</div>
    <div>Gül</div>
    <div>Üzüm</div>
  </div>
</template>

<script setup></script>
